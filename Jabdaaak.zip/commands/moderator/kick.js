module.exports = {

    name: "추방",
    description:""
}